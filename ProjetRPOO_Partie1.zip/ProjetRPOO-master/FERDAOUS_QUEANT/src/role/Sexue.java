package role;

public class Sexue extends Role{
	public double[] getVitalite() {
		double[] vita = {1.5, 2.5};
		return vita;
	}
}
