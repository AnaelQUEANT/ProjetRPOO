package role;

public abstract class Role {
	public abstract double[] getVitalite();
	
}
