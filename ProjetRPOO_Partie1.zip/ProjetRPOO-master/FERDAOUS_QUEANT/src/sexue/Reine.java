package sexue;

public class Reine extends Femelle{
	@Override
	public double[] getVitalite() {
		double[] vita = {4, 10};
		return vita;
	}
}
